function Foo() {
    console.log('Foo');
}

Foo.prototype.Bar = function () {
    function Qux() {
        console.log('Qux');
    }
    Qux();
    console.log('Bar');
}

var f = new Foo();

f.Bar();
//f.Bar.Qux(); - niemozliwe