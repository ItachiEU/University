let a = require('./biblio1.js')

a.func_1(5);