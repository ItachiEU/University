# Joanna Mielniczuk, lista 5.

"""
Rozwiązanie listy 5.
Przedstawia reprezentację wyrażeń algebraicznych.
"""


# Zadanie 1., wariant C
class Wyrazenie:
    """
    Nadklasa reprezentująca wyrażenia.
    """
    def oblicz(self, zmienne):
        ...

    def __str__(self):
        ...

    def __add__(self, w):
        return Dodaj(self, w)

    def __mul__(self, w):
        return Razy(self, w)

    @staticmethod
    def pochodna(w, zmienna):
        if isinstance(w, Stala):
            return Stala(0)
        elif isinstance(w, Zmienna):
            if zmienna == w.symbol:
                return Stala(1)
            else:
                return Stala(0)
        elif isinstance(w, Dodaj):
            return Dodaj(
                Wyrazenie.pochodna(w.w1, zmienna),
                Wyrazenie.pochodna(w.w2, zmienna))
        elif isinstance(w, Odejmij):
            return Odejmij(
                Wyrazenie.pochodna(w.w1, zmienna),
                Wyrazenie.pochodna(w.w2, zmienna))
        elif isinstance(w, Razy):
            return Dodaj(
                Razy(Wyrazenie.pochodna(w.w1, zmienna), w.w2),
                Razy(w.w1, Wyrazenie.pochodna(w.w2, zmienna)))
        elif isinstance(w, Podziel):
            return Podziel(
                Odejmij(
                    Razy(Wyrazenie.pochodna(w.w1, zmienna), w.w2),
                    Razy(w.w1, Wyrazenie.pochodna(w.w2, zmienna))),
                Razy(w.w2, w.w2))
        else:
            None


class Stala(Wyrazenie):
    """
    Podklasa reprezentująca stałe liczbowe.
    """
    def __init__(self, wartosc):
        self.wartosc = wartosc

    def oblicz(self, zmienne):
        return self.wartosc

    def __str__(self):
        return str(self.wartosc)


class Zmienna(Wyrazenie):
    """
    Podklasa reprezentująca zmienne.
    """
    def __init__(self, symbol):
        self.symbol = symbol

    def oblicz(self, zmienne):
        if self.symbol in zmienne.keys():
            return zmienne[self.symbol]
        else:
            raise BrakWartosciZmiennej()

    def __str__(self):
        return self.symbol


class Dodaj(Wyrazenie):
    """
    Podklasa reprezentująca sumę wyrażeń.
    """
    def __init__(self, w1, w2):
        self.w1 = w1
        self.w2 = w2

    def oblicz(self, zmienne):
        return self.w1.oblicz(zmienne) + self.w2.oblicz(zmienne)

    def __str__(self):
        lewy = self.w1.__str__()
        prawy = self.w2.__str__()

        if lewy == '0':
            return prawy

        if prawy == '0':
            return lewy

        return lewy + " + " + prawy


class Odejmij(Wyrazenie):
    """
    Podklasa reprezentująca odejmowanie wyrażeń.
    """
    def __init__(self, w1, w2):
        self.w1 = w1
        self.w2 = w2

    def oblicz(self, zmienne):
        return self.w1.oblicz(zmienne) - self.w2.oblicz(zmienne)

    def __str__(self):
        lewy = self.w1.__str__()
        prawy = self.w2.__str__()

        if lewy == '0':
            return '-(' + prawy + ')'

        if prawy == '0':
            return lewy

        return lewy + " - " + prawy


class Razy(Wyrazenie):
    """
    Podklasa reprezentująca mnożenie wyrażeń.
    """
    def __init__(self, w1, w2):
        self.w1 = w1
        self.w2 = w2

    def oblicz(self, zmienne):
        return self.w1.oblicz(zmienne) * self.w2.oblicz(zmienne)

    def __str__(self):
        lewy = self.w1.__str__()
        prawy = self.w2.__str__()

        if prawy == '1' or lewy == '0':
            return lewy
        if lewy == '1' or prawy == '0':
            return prawy

        result = ''

        if isinstance(self.w1, (Dodaj, Odejmij)):
            result += '(' + lewy + ')'
        else:
            result += lewy

        result += ' * '

        if isinstance(self.w2, (Dodaj, Odejmij)):
            result += '(' + prawy + ')'
        else:
            result += prawy

        return result


class Podziel(Wyrazenie):
    """
    Podklasa reprezentująca dzielenie wyrażeń.
    """
    def __init__(self, w1, w2):
        self.w1 = w1
        self.w2 = w2

    def oblicz(self, zmienne):
        mianownik = self.w2.oblicz(zmienne)

        if mianownik == 0:
            raise DzieleniePrzezZero()

        return self.w1.oblicz(zmienne) / mianownik

    def __str__(self):
        lewy = self.w1.__str__()
        prawy = self.w2.__str__()
        result = ''

        if lewy == '0' or prawy == '1':
            return lewy

        if isinstance(self.w1, (Dodaj, Odejmij)):
            result += '(' + lewy + ')'
        else:
            result += lewy

        result += ' / '

        if isinstance(self.w2, (Dodaj, Odejmij)):
            result += '(' + prawy + ')'
        else:
            result += prawy

        return result


# wyjątki
class BrakWartosciZmiennej(Exception):
    """
    Wyjątek rzucany w przypadku braku wartości \
    zmiennej w przekazywanym kontekście.
    """
    def __init__(self, msg="Brak wartości zmiennej!"):
        self.message = msg
        super().__init__(self, msg)


class DzieleniePrzezZero(Exception):
    """
    Wyjątek rzucany przy dzieleniu przez 0.
    """
    def __init__(self, msg="Dzielenie przez zero!"):
        self.message = msg
        super()


zmienne = dict()
zmienne['x'] = 2
zmienne['y'] = 2

'''
w1 = Odejmij(Razy(Stala(5), Zmienna('x')), Zmienna('y'))
print(w1)
print(w1.oblicz(zmienne))

print(w1.__add__(Stala(11)))
print(w1.__mul__(Stala(11)))
print(Wyrazenie.pochodna(w1, 'x'))

w2 = w1.__mul__(Zmienna('x'))
print(w2)
print(Wyrazenie.pochodna(w2, 'x'))
'''
