# Joanna Mielniczuk, lista 4.

from numpy import zeros, argsort

# Zadanie 2.
def shadow(vecH, vecV):
    # użyjemy zachłannego algorytmu malowania kratek
    idxH = argsort(vecH)[::-1]
    idxV = argsort(vecV)[::-1]

    w = len(vecH)
    h = len(vecV)
    # ile zostało do pomalowania w wierszu/kolumnie
    leftH = vecH
    leftV = vecV
    # wynik
    result = zeros((h, w))

    for i in range(w):
        j = 0
        while leftH[idxH[i]] > 0 and j < h:
            if result[idxV[j]][idxH[i]] == 0 and leftV[idxV[j]] > 0:
                result[idxV[j]][idxH[i]] = 1
                leftH[idxH[i]] -= 1
                leftV[idxV[j]] -= 1
            j += 1

        # jeśli coś zostało w kolumnie to zwróć None
        if leftH[idxH[i]] > 0:
            return None

    # jeśli coś zostało w wierszach to zwróć None
    for j in range(h):
        if leftV[j] > 0:
            return None

    return result

# wyświetlanie wyniku
def printNicely(result):
    if result is None:
        print('None!')
    else:
        for row in result:
            output = ['#' if f == 1 else ' ' for f in row]
            print(''.join(output))

printNicely(shadow([2, 1, 3, 1], [1, 3, 1, 2]))
print()
printNicely(shadow([2, 2, 2, 1], [2, 2, 1, 2]))
print()
printNicely(shadow([4, 1, 1, 3, 2], [2, 2, 4, 1, 2]))