# Joanna Mielniczuk, lista 11.
# podpunkt B i D

import pstats
import cProfile
import io

# podpunkt C
prf = cProfile.Profile()
prf.enable()
prf.run('import L1_styled')
prf.disable()

s = io.StringIO()
ps = pstats.Stats(prf, stream=s).sort_stats('cumtime')
ps.print_stats()

with open('stats.txt', 'w+') as f:
    f.write(s.getvalue())

# podpunkt D
'''
Do wygenerowania dokumentacji:
pydoc -w L1_styled.py
pydoc -w L5_styled.py
'''
