# Joanna Mielniczuk, lista 7.
# Zadanie 1.

import re
from bs4 import BeautifulSoup as bs
import urllib.request
from django.core.validators import URLValidator
from django.core.exceptions import ValidationError
import threading
import multiprocessing as mp

def find_sentences(text, keyword='Python'):
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!)', text)
    sentences = [s.strip() for s in sentences]
    sentences = list(filter(lambda x: x.find(keyword) != -1, sentences))
    
    return sentences

def make_soup(url):
    validator = URLValidator()
    try:
        validator(url)
    except ValidationError:
        return -1

    try:
        page = urllib.request.urlopen(url)
    except urllib.request.HTTPError:
        return -1
    except UnicodeEncodeError:
        return -1

    request = urllib.request.Request(url, headers={'User-Agent': 'Chrome/83.0.4103.97'})
    try:
        page = urllib.request.urlopen(request).read()
    except UnicodeEncodeError:
        return -1

    return bs(page, 'html.parser')

def get_hrefs(url):
        soup = make_soup(url)
        if soup == -1:
            return []

        hrefs = []
        for l in soup.findAll('a'):
            hrefs.append(l.get('href'))

        result = []
        for l in hrefs:
            if (l is not None and len(l) > 0 
                and (l.find('https') == 0 or l.find('http') == 0)):
                    result.append(l)

        return result

def get_text(url):
    soup = make_soup(url)
    if soup == -1:
        return ""
    for script in soup(["script", "style"]):
        script.decompose()
    strips = list(soup.stripped_strings)
    return " ".join(strips)

class Crawler:
    def __init__(self, start_page, distance, action):
        self.start_page = start_page
        self.distance = distance
        self.action = action
        self.visited = [start_page]
        links = threading.Thread(target=self.get_links, args=(self.start_page, 1))
        links.start()
        links.join()

    def get_links(self, page, distance):
        links = get_hrefs(page)
        for l in links:
            if l not in self.visited:
                self.visited.append(l)
                if distance < self.distance:
                    threading.Thread(target=self.get_links,
                        args=(l, distance + 1)).start()

    def get_result(self):
        with mp.Pool() as pool:
            result = pool.map(get_text, self.visited)
            result = list(map(find_sentences, result))
            result = list(zip(self.visited, result))
            return iter(result)

crawler = Crawler("https://pl.wikipedia.org/wiki/J%C4%99zyk_programowania", 2, find_sentences)
myIter = crawler.get_result()
for i in myIter:
    print(i)