# Joanna Mielniczuk, lista 8.
# Zadanie 2.

from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import sys
from sqlalchemy.inspection import inspect

Base = declarative_base()

class Movie(Base):
    __tablename__ = 'Movies'

    nr = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    year = Column(Integer, nullable=False)
    director = Column(String, nullable=False)
    operator = Column(String, nullable=False)
    producer = Column(String, nullable=False)

    def __str__(self):
        return (f'Nr {self.nr}, Title: {self.title}, ' + \
            f'Year: {self.year}, Director: {self.director}, ' + \
            f'Operator: {self.operator}, Producer: {self.producer}')

def executeQuery(**kwargs):
    engine = create_engine('sqlite:///movies.db', echo=False)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()

    flag = kwargs['flag']

    if  flag == '--print':
        for m in session.query(Movie).all():
            print(m)
    elif flag == '--add':
        m = Movie(title=kwargs['title'],
                year=kwargs['year'],
                director=kwargs['director'],
                operator=kwargs['operator'],
                producer=kwargs['producer'])
        session.add(m)
        session.commit()
        print('Added: ', m)
    elif flag == '--delete':
        toDelete = session.query(Movie).filter(inspect(Movie).primary_key[0] == kwargs['nr'])
        for m in toDelete:
            print('Deleting: ', m)
            session.delete(m)
        session.commit()

'''
    WYPISZ WSZYSTKIE -> python3 L8.py --print
    DODAJ NOWY -> python3 L8.py --add [title] [year] [director] [operator] [producer]
    USUŃ (po nr) -> python3 L8.py --delete [nr]
'''

if __name__ == '__main__':
    numOfArgs = len(sys.argv)
    if numOfArgs == 1:
        print('No command!')
    else:
        command = sys.argv[1]

        if command == '--print' and numOfArgs == 2:
            executeQuery(flag='--print')
        elif command == '--add' and numOfArgs == 7:
            executeQuery(flag='--add', title=sys.argv[2],
                                        year=sys.argv[3],
                                        director=sys.argv[4],
                                        operator=sys.argv[5],
                                        producer=sys.argv[6])
        elif command == '--delete' and numOfArgs == 3:
            executeQuery(flag='--delete', nr=sys.argv[2])
        else:
            print('Wrong command or number of args!')