# Joanna Mielniczuk, lista 11.
# podpunkt A

import unittest
from L1_styled import is_palindrom
from L5_styled import \
    Stala, Zmienna, BrakWartosciZmiennej, \
    DzieleniePrzezZero, Podziel


# testy zadania 3. z listy 1.
class TestEmptyString(unittest.TestCase):
    def runTest(self):
        self.assertFalse(is_palindrom(''))


class TestWeirdCharacters(unittest.TestCase):
    def runTest(self):
        self.assertTrue(is_palindrom('Eine güldne, gute Tugend: Lüge nie!'))


class TestCorrectPalindrom(unittest.TestCase):
    def runTest(self):
        self.assertTrue(is_palindrom('Ada bez Rubika maki, burze bada.'))


class TestOneLetter(unittest.TestCase):
    def runTest(self):
        self.assertTrue(is_palindrom('A'))


class TestIncorrectPalindrom(unittest.TestCase):
    def runTest(self):
        self.assertFalse(is_palindrom('Asikson'))


def palindromSuite():
    testSuite = unittest.TestSuite()
    testSuite.addTest(unittest.makeSuite(TestEmptyString))
    testSuite.addTest(unittest.makeSuite(TestWeirdCharacters))
    testSuite.addTest(unittest.makeSuite(TestCorrectPalindrom))
    testSuite.addTest(unittest.makeSuite(TestOneLetter))
    testSuite.addTest(unittest.makeSuite(TestIncorrectPalindrom))

    return testSuite


# testy do zadania 1. z listy 5. (wariant C.)
class TestVarSubstitution(unittest.TestCase):
    def runTest(self):
        zmienne = dict()
        zmienne['x'] = 2
        zmienne['y'] = 7
        w = Stala(5).__mul__(Zmienna('x')).__add__(Zmienna('y'))
        self.assertEqual(w.oblicz(zmienne), 17)


class TestLackOfVar(unittest.TestCase):
    def runTest(self):
        zmienne = dict()
        zmienne['x'] = 2
        w = Stala(5).__mul__(Zmienna('x')).__add__(Zmienna('y'))
        self.assertRaises(BrakWartosciZmiennej, lambda: w.oblicz(zmienne))


class ZeroDivision(unittest.TestCase):
    def runTest(self):
        zero = Stala(0)
        w = Stala(5).__add__(Stala(2))
        self.assertRaises(
            DzieleniePrzezZero,
            lambda: Podziel(w, zero).oblicz([]))


def wyrazeniaSuite():
    testSuite = unittest.TestSuite()
    testSuite.addTest(unittest.makeSuite(TestVarSubstitution))
    testSuite.addTest(unittest.makeSuite(TestLackOfVar))
    testSuite.addTest(unittest.makeSuite(ZeroDivision))

    return testSuite


suite1 = palindromSuite()
suite2 = wyrazeniaSuite()

runner = unittest.TextTestRunner()
runner.run(suite1)
runner.run(suite2)
