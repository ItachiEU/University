# Joanna Mielniczuk, lista 1.
# zadania 1., 2. i 4.

"""
Rozwiązanie listy 1.
Przedstawia:
1. dwa sposoby obliczania wartości podatku VAT
2. funkcję sprawdzającą czy dany wyraz jest palindromem
3. funkcję symulującą rzuty monetą.
"""

import decimal as d
import random

# Zadanie 1.
vat = 0.23
vat_dec = d.Decimal('0.23')


def vat_faktura(lista):
    """
    Oblicza wartość podatku VAT na fakturze.
    :lista: lista pozycji faktury
    :zwraca: sumę wartości podatku pozycji faktury
    """
    suma = 0
    for p in lista:
        suma += p

    return suma * vat


def vat_paragon(lista):
    """
    Oblicza wartość podatku VAT na paragonie.
    :lista: lista pozycji paragonu
    :zwraca: sumę wartości podatku pozycji paragonu
    """
    suma = 0
    for p in lista:
        suma += p * vat

    return suma


def vat_faktura_dec(lista):
    """
    Oblicza wartość podatku VAT na fakturze z użyciem klasy Decimal.
    :lista: lista pozycji faktury
    :zwraca: sumę wartości podatku pozycji faktury
    """
    suma = d.Decimal('0')
    for p in lista:
        suma += p

    return suma * vat_dec


def vat_paragon_dec(lista):
    """
    Oblicza wartość podatku VAT na paragonie z użyciem klasy Decimal.
    :lista: lista pozycji paragonu
    :zwraca: sumę wartości podatku pozycji paragonu
    """
    suma = d.Decimal('0')
    for p in lista:
        suma += p * vat_dec

    return suma


zakupy = [0.2, 0.5, 4.59, 6]
zakupy_dec = [
    d.Decimal('0.2'), d.Decimal('0.5'),
    d.Decimal('4.59'), d.Decimal('6')]

faktura = vat_faktura(zakupy)
paragon = vat_paragon(zakupy)

faktura_dec = vat_faktura_dec(zakupy_dec)
paragon_dec = vat_paragon_dec(zakupy_dec)

'''
print('FLOAT:')
print(faktura)
print(paragon)
print(faktura == paragon)

print('\nDECIMAL:')
print(faktura_dec)
print(paragon_dec)
print(faktura_dec == paragon_dec)
'''

# Zadanie 2.
stops = [
    ' ', ',', '.', ':', ';', '?',
    '!', '"', '(', ')', '-']


def is_palindrom(text):
    """
    Sprawdza czy podany tekst jest palindromem.
    :text: słowo do sprawdzenia
    :zwraca: Prawda/Fałsz
    """
    b = 0
    e = len(text) - 1

    if e < b:
        return False

    while (b < e):
        while text[b] in stops:
            b += 1
        while text[e] in stops:
            e -= 1
        if b >= e:
            break

        if (text[b].lower() != text[e].lower()):
            return False

        b += 1
        e -= 1

    return True


assert(is_palindrom('rotor'))
assert(is_palindrom('Kobyła ma mały bok.'))
assert(is_palindrom('Eine güldne, gute Tugend: Lüge nie!'))
assert(not is_palindrom('Zdecydowanie nie palindrom.'))


# Zadanie 4.
def flip(n):
    """
    Wykonuje n eksperymentów polegających na rzucie monetą do momentu, \
    aż nie wypadną trzy te same strony pod rząd.
    :n: ilość eksperymentów
    :zwraca: średnią ilość rzutów wykonaną w pojedynczym eksperymencie
    """
    def experiment():
        r = 0
        o = 0
        i = 0

        while True:
            i += 1
            f = random.randint(0, 1)

            if (f == 0):
                r += 1
                o = 0
            else:
                o += 1
                r = 0

            if r == 3 or o == 3:
                return i

    sum = 0
    for i in range(n):
        sum += experiment()

    return sum / n


flip(10)
flip(50)
