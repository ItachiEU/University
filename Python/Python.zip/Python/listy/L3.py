# Joanna Mielniczuk, lista 3.
# Zadania 1 i 2 

import timeit as t

imp = 'import math as m\n'

# Zadanie 1.
pierwsze_imperatywna = '''
def pierwsze_imperatywna(n):
    if n < 2:
        return []

    wynik = []
    i = 2

    while i <= n:
        if i == 2 or i == 3:
            wynik.append(i)
        else:
            j = 2
            p = m.floor(m.sqrt(i))
            while j <= p:
                if i % j == 0:
                    break
                elif j == p:
                    wynik.append(i)
                j += 1
        i += 1
    return wynik'''

s1 = 'pierwsze_imperatywna(20)'

pierwsze_skladana = '''
def pierwsze_skladana(n):
    return [i for i in range(2, n + 1) 
        if i == 2 or i == 3 
            or all(i % j != 0 for j in range(2, m.floor(m.sqrt(i)) + 1))]''' 

s2 = 'pierwsze_skladana(20)'

pierwsze_funkcyjna = '''
def pierwsze_funkcyjna(n):
    def czy_pierwsza(i):
        dzielniki = list(filter(lambda j: i % j == 0 and i != 2, 
                        range(2, m.floor(m.sqrt(i)) + 1)))
        return len(dzielniki) == 0
    
    return list(filter(czy_pierwsza, range(2, n + 1)))'''
    
s3 = 'pierwsze_funkcyjna(20)'

print(t.timeit(setup=imp + pierwsze_imperatywna, stmt=s1, number=1000))
print(t.timeit(setup=imp + pierwsze_skladana, stmt=s2, number=1000))
print(t.timeit(setup=imp + pierwsze_funkcyjna, stmt=s3, number=1000))

# Zadanie 2.
doskonale_imperatywna = '''
def doskonale_imperatywna(n):
    # najmniejszą doskonałą jest 6
    if n < 6:
        return []

    i = 6
    wynik = []

    while i <= n:
        j = 1
        suma = 0
        while j < i:
            if i % j == 0:
                suma += j
            j += 1
        if suma == i:
            wynik.append(i)
        i += 1
    
    return wynik'''
    
s4 = 'doskonale_imperatywna(1000)'

doskonale_skladana = '''
def doskonale_skladana(n):
    return [i for i in range(6, n + 1)
        if sum([j for j in range(1, i) if i % j == 0]) == i]'''

s5 = 'doskonale_skladana(1000)'

doskonale_funkcyjna = '''
def doskonale_funkcyjna(n):
    def czy_doskonala(i):
        dzielniki = list(filter(lambda j: i % j == 0, 
                        range(1, i)))
        return sum(dzielniki) == i
    
    return list(filter(czy_doskonala, range(6, n + 1)))'''

s6 = 'doskonale_funkcyjna(1000)'

print(t.timeit(setup=doskonale_imperatywna, stmt=s4, number=100))
print(t.timeit(setup=doskonale_skladana, stmt=s5, number=100))
print(t.timeit(setup=doskonale_funkcyjna, stmt=s6, number=100))