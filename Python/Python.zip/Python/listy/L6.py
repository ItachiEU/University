# Joanna Mielniczuk, lista 6.
# Zadanie 1.

from bs4 import BeautifulSoup as bs
import re
import urllib.request
from django.core.validators import URLValidator
from django.core.exceptions import ValidationError

def crawl(start_page, distance, action):

    def get_hrefs(url):
        soup = make_soup(url)
        if soup == -1:
            return []

        hrefs = []
        for l in soup.findAll('a'):
            hrefs.append(l.get('href'))

        result = []
        for l in hrefs:
            if (l is not None and len(l) > 0 
                and (l.find('https') == 0 or l.find('http') == 0)):
                    result.append(l)

        return result

    def make_soup(url):
        validator = URLValidator()
        try:
            validator(url)
        except ValidationError:
            return -1

        try:
            page = urllib.request.urlopen(url)
        except urllib.request.HTTPError:
            return -1
        except UnicodeEncodeError:
            return -1

        request = urllib.request.Request(url, headers={'User-Agent': 'Chrome/83.0.4103.97'})
        try:
            page = urllib.request.urlopen(request).read()
        except UnicodeEncodeError:
            return -1

        return bs(page, 'html.parser')

    def get_text(url):
        soup = make_soup(url)
        if soup == -1:
            return ""

        for script in soup(["script", "style"]):
            script.decompose()
        strips = list(soup.stripped_strings)
        return " ".join(strips)

    visited = set()
    results = []

    def crawl_r(page, distance):
        links = filter(lambda x: x not in visited, get_hrefs(page))

        for l in links:
            visited.add(l)
            results.append((l, action(get_text(l))))

        if distance > 0:
            crawl_r(l, distance - 1)        

    crawl_r(start_page, distance)
    return iter(results)

def find_sentences(text, keyword='Python'):
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!)', text)
    sentences = [s.strip() for s in sentences]
    sentences = list(filter(lambda x: x.find(keyword) != -1, sentences))
    
    return sentences

myIter = crawl("https://github.com/andialbrecht/sqlparse", 0, find_sentences)
for i in myIter:
    print(i)