# Joanna Mielniczuk, lista 2.
# zadania 1, 2 i 4

import math
import numpy

# Zadanie 1.

class wynik:
    def __init__(self, osoba, komitet, glosy):
        self.osoba = osoba
        self.komitet = komitet
        self.glosy = glosy

# liczby głosów i komitety z przykładu z Wikipedii
wyniki = [wynik('Jan Kowalski', 'PO', 700),
    wynik('Jan Nowak', 'PO', 20),
    wynik('Jakub Marecki', 'PIS', 100),
    wynik('Ignacy Marecki', 'PIS', 100),
    wynik('Alicja Marecka', 'PIS', 100),
    wynik('Marcin Wilk', 'PSL', 480),
    wynik('jakaś mniejszość narodowa', 'MN', 1)]

def mandaty(wynikWyborow, miejsca):
    # wczytywanie komitetów i sumowanie głosów
    wszystkie_komitety = dict()
    suma = 0
    for w in wynikWyborow:
        if (w.komitet in wszystkie_komitety.keys()):
            wszystkie_komitety[w.komitet] += w.glosy
        else:
            wszystkie_komitety[w.komitet] = w.glosy
        suma += w.glosy

    # sprawdzanie progu
    komitety = dict()
    for k in wszystkie_komitety.keys():
        if wszystkie_komitety[k] >= 0.05 * suma:
            komitety[k] = wszystkie_komitety[k]
    
    # obliczanie potrzebnych ilorazów
    ilorazy = []
    d = 1

    nowe = [(k, komitety[k]/ d) for k in komitety.keys()]
    nowe.sort(reverse=True, key=lambda x: x[1])

    while (len(ilorazy) < miejsca
        or nowe[0][1] > ilorazy[miejsca - 1][1]):
        
        ilorazy += nowe
        ilorazy.sort(reverse=True, key=lambda x: x[1])
        d += 1
        nowe = [(k, komitety[k]/ d) for k in komitety.keys()]
        nowe.sort(reverse=True, key=lambda x: x[1])
    
    ilorazy = ilorazy[:miejsca]
    wyniki = dict()
    for i in ilorazy:
        if (i[0] in wyniki.keys()):
            wyniki[i[0]] += 1
        else:
            wyniki[i[0]] = 1
    
    return wyniki

# podział mandatów się zgadza
print(mandaty(wyniki, 8))


# Zadanie 2.

def pierwiastek(n):
    if n < 0:
        Exception("Podano liczbę ujemną.")

    if n == 0:
        return 0

    i = 1
    suma = 0

    while suma <= n:
        suma += 2*i - 1
        i += 1

    return i - 2

print(pierwiastek(10))
print(pierwiastek(25))
print(pierwiastek(33.3))
print(pierwiastek(100))
print(pierwiastek(101))


# Zadanie 4.

def uprosc_zdanie(tekst, dl_slowa, liczba_slow):
    wynik = []

    for s in tekst.split():
        if len(s) <= dl_slowa:
            wynik.append(s)

    if len(wynik) > liczba_slow:
        perm = numpy.random.permutation(len(wynik))
        for i in range(len(wynik) - liczba_slow):
            wynik[perm[i]] = ''

    return ' '.join(wynik)

tekst = "Podział peryklinalny inicjałów wrzecionowatych \
kambium charakteryzuje się ścianą podziałową inicjowaną \
w płaszczyźnie maksymalnej."
print(uprosc_zdanie(tekst, 10, 5))

# wiersz W. Szymborskiej
nic_dwa_razy = "Nic dwa razy się nie zdarza \
i nie zdarzy. Z tej przyczyny \
zrodziliśmy się bez wprawy \
i pomrzemy bez rutyny. \
Choćbyśmy uczniami byli \
najtępszymi w szkole świata,\
nie będziemy repetować \
żadnej zimy ani lata. \
Żaden dzień się nie powtórzy, \
nie ma dwóch podobnych nocy, \
dwóch tych samych pocałunków,\
dwóch jednakich spojrzeń w oczy. \
\
Wczoraj, kiedy twoje imię \
ktoś wymówił przy mnie głośno, \
tak mi było jakby róża \
przez otwarte wpadła okno. \
Dziś, kiedy jesteśmy razem, \
odwróciłam twarz ku ścianie. \
Róża? Jak wygląda róża? \
Czy to kwiat? A może kamień? \
\
Czemu ty się, zła godzino, \
z niepotrzebnym mieszasz lękiem? \
Jesteś - a więc musisz minąć. \
Miniesz - a więc to jest piękne. \
Uśmiechnięci, współobjęci \
spróbujemy szukać zgody, \
choć różnimy się od siebie \
jak dwie krople czystej wody."

# wiersz W. Szymborskiej w 50 słowach (nie czyta się wcale łatwiej)
print(uprosc_zdanie(nic_dwa_razy, 10, 50))
