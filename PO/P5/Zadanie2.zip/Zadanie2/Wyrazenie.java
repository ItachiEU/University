
public interface Wyrazenie {
   public int Oblicz();
}