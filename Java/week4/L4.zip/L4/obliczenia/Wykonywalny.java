package obliczenia;

public interface Wykonywalny {
   void wykonaj();
}
