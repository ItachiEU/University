package obliczenia;

public abstract class Instrukcja implements Wykonywalny {

}
