import test.*;

public class Main {
   public static void main(String[] args) {
      Test1 t = new Test1();
      t.run();
      System.out.println("=========================");
      Test2 t2 = new Test2();
      t2.run();
   }
}
