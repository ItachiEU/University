package figury;

public class Odcinek implements Figura {

   public Punkt start, koniec;

   public Odcinek(Punkt a, Punkt b) {
      start = a;
      koniec = b;
   }

   @Override
   public void translacja(Wektor v) {
      start.setX(start.getX() + v.dx);
      start.setY(start.getY() + v.dy);
      koniec.setX(koniec.getX() + v.dx);
      koniec.setY(koniec.getY() + v.dy);
   }

   @Override
   public void obrot(Punkt p, double kat) {
      start.setX((start.getX() - p.getX()) * Math.cos(kat) + (start.getY() - p.getY()) * Math.sin(kat) + p.getX());
      start.setY(
            Math.abs((start.getX() - p.getX()) * Math.sin(kat) - (start.getY() - p.getY()) * Math.cos(kat) - p.getY()));

      koniec.setX((koniec.getX() - p.getX()) * Math.cos(kat) + (koniec.getY() - p.getY()) * Math.sin(kat) + p.getX());
      koniec.setY(Math
            .abs((koniec.getX() - p.getX()) * Math.sin(kat) - (koniec.getY() - p.getY()) * Math.cos(kat) - p.getY()));

   }

   @Override
   public void odbij(Prosta l) {
      double A = l.a / -l.b;

      start.setX((1 - A * A) / (1 + A * A) * start.getX() + 2 * A / (1 + A * A) * start.getY());
      start.setY(2 * A / (1 + A * A) * start.getX() - (1 - A * A) / (1 + A * A) * start.getY());

      koniec.setX((1 - A * A) / (1 + A * A) * koniec.getX() + 2 * A / (1 + A * A) * koniec.getY());
      koniec.setY(2 * A / (1 + A * A) * koniec.getX() - (1 - A * A) / (1 + A * A) * koniec.getY());
   }

}